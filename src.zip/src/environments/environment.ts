// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig : {
    apiKey: "AIzaSyAZRtfS-sd1wGV-hNBt0SpmDu93hlP6lrk",
    authDomain: "epe34-bd585.firebaseapp.com",
    databaseURL: "https://epe34-bd585.firebaseio.com",
    projectId: "epe34-bd585",
    storageBucket: "",
    messagingSenderId: "607862823384",
    appId: "1:607862823384:web:d157dfad7c4370bf"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
